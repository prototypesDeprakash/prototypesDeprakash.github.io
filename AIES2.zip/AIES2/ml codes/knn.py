from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.datasets import load_iris
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt

dt = load_iris()
x = dt.data
y = dt.target

x_train, x_test, y_train, y_test = train_test_split(x,y,test_size = 0.3)

model = KNeighborsClassifier(n_neighbors = 3)
model.fit(x_train,y_train)

y_pred = model.predict(x_test)

print("Predicted Values : ", y_pred)
print("Accuracy score : ", accuracy_score(y_pred,y_test))

plt.figure()
plt.title("KNN")
plt.scatter(x[:,0],x[:,1],c=y)
plt.xlabel("Sepal Length(cm)")
plt.ylabel("Sepal Width(cm)")
plt.show()