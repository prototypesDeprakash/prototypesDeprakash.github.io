board=[]
for i in range(9):
    board.append(" ")

def print_board():
    print()
    print(board[0],'|',board[1],'|',board[2])
    print("--+--+--")
    print(board[3],'|',board[4],'|',board[5])
    print("--+--+--")
    print(board[6],'|',board[7],'|',board[8])
    print()

def check_winner(player):
    if(board[0]==board[1]==board[2]==player):
        return True
    if(board[3]==board[4]==board[5]==player):
        return True
    if(board[6]==board[7]==board[8]==player):
        return True
    #---------------------------------------#
    if(board[0]==board[3]==board[6]==player):
        return True
    if(board[1]==board[4]==board[7]==player):
        return True
    if(board[2]==board[5]==board[8]==player):
        return True
    if(board[0]==board[4]==board[8]==player):
        return True
    if(board[2]==board[4]==board[6]==player):
        return True
    return False
def play_Game():
    current_player ="X"
    for i in range(9):
        print_board()
        move = int(input(f"Player = {current_player} , Choose move =(0-8)" ))
        if(board[move]!=" "):
            print("enter a valid move")
            continue
        board[move]=current_player
        if(check_winner(current_player)):
            print_board()
            print(f"{current_player} wins the match")
            return
        current_player ="O" if current_player=="X" else "X"
    print_board()
    print("Draw")
play_Game()
