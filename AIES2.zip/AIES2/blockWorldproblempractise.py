goal=['a','b','c','d']
table=['b','a','d','c']
result=[]
def solver(table,stpes=0):
    if(stpes==len(goal)):
        return True
    for i in range(len(table)):
        if(table[i]==goal[stpes]):
            block = table.pop(i)
            result.append(block)
            if(solver(table,stpes+1)):
                return True
            removed = result.pop()
            table.insert(i,removed)
if(solver(table.copy())):
    print("solved")
    print(result)
else:
    print("cannot solve bro")

