graph = {
'A':['B','C'],
'B':['A','C','D'],
'C':['A','B','D'],
'D':['B','C']
    }
colors =['R' ,'G','B']

node_colors={}

for node in graph:
    used_colors=[]
    for neighbour in graph[node]:
        if neighbour in node_colors:
            used_colors.append(node_colors[neighbour])
    for color in colors:
        if color not in used_colors:
            node_colors[node]=color
            break
for node in node_colors:
    print(node_colors[node])
