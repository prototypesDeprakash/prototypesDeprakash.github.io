from sklearn.datasets import load_iris
from sklearn.tree import DecisionTreeClassifier , plot_tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import matplotlib.pyplot as plt


iris = load_iris()
x = iris.data
y=iris.target

x_test,x_train , y_test,y_train = train_test_split(x,y,train_size=0.2,random_state=45)

model = DecisionTreeClassifier()
model.fit(x_train,y_train)

predict = model.predict(x_test)
print(accuracy_score(y_test,predict))
plot_tree(model)
plt.show()