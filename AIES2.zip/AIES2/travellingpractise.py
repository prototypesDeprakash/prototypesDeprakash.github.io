import itertools
distance_matrix = [
    [0, 10, 15, 20],   # Distances from city 0 to others
    [10, 0, 35, 25],   # From city 1
    [15, 35, 0, 30],   # From city 2
    [20, 25, 30, 0]    # From city 3
]

cities_to_visit = [i for i in range(1,4)]
min_cost = float('inf')
min_path=[]
all_possible_path = itertools.permutations(cities_to_visit)

for one_path in all_possible_path:
    current_path=[]
    cost=0
    
    current_path.append(0)
    for cities in one_path:
        current_path.append(cities)
    current_path.append(0)
    for i in range(len(current_path)-1):
        start = current_path[i]
        end = current_path[i+1]
        cost += distance_matrix[start][end]
    if(cost<min_cost):
        min_cost=cost
        min_path=current_path
print(min_cost)
print(min_path)


