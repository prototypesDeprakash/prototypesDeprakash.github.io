import heapq

def heuristic(a, b):
    # Manhattan distance
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def neighbors(node):
    x, y = node
    for dx, dy in [(-1,0),(1,0),(0,-1),(0,1)]:
        yield (x+dx, y+dy), 1  # move cost = 1

def astar(start, goal):
    open_set = [(heuristic(start, goal), 0, start, [])]
    visited = set()
    while open_set:
        #part 1
        est, cost, node, path = heapq.heappop(open_set)
        if node in visited: continue
        path = path + [node]
        if node == goal: return path
        visited.add(node)
        #part 2
        for next_node, step_cost in neighbors(node):
            if next_node not in visited:
                g = cost + step_cost
                f = g + heuristic(next_node, goal)
                heapq.heappush(open_set, (f, g, next_node, path))
start = (0, 0)
goal = (3, 3)
path = astar(start, goal)
print(path)
