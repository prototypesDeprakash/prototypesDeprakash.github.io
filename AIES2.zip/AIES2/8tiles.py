from collections import deque;

goal_state = '123456780'
moves = {
0: [1, 3],
1: [0, 2, 4],
2: [1, 5],
3: [0, 4, 6],
4: [1, 3, 5, 7],
5: [2, 4, 8],
6: [3, 7],
7: [4, 6, 8],
8: [5, 7]
}

def swap(state, i,j):
    state = list(state)
    state[i],state[j]=state[j],state[i]
    return ''.join(state)
def bfs(start_state):
    queue  = deque()
    visited =set()
    queue.append((start_state,[]))
    while queue:
        #part 1 check if current sate is goal if yes return , else add it to visited
        current_state , path = queue.popleft()
        if(current_state==goal_state):
            print("solved")
            return 
        visited.add(current_state)
        #part 2
        zero_pos = current_state.index('0')
        for move in moves[zero_pos]:
            new_state= swap(current_state,zero_pos,move)
            if(new_state not in visited):
                queue.append((new_state,path+[current_state]))

start = '724506831'
bfs(start)

            

