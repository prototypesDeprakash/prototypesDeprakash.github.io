import random

def f(x):
    return -(x - 3)**2 + 9  # Peak at x = 3

x = random.uniform(-10, 10)  # Random start
step = 0.1

for _ in range(100):
    # Try moving left and right
    neighbors = [x, x + step, x - step]
    # Pick the one with the best value
    x = max(neighbors,key=f)

print("Best x:", x)
print("Function value:", f(x))
