import pandas as pd
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from sklearn.metrics import silhouette_score
import matplotlib.pyplot as plt
# Step 1: Load CSV file
df = pd.read_csv("data.csv")
X = df.values # convert to numpy array
# Step 2: Apply k-Means clustering
kmeans = KMeans(n_clusters=2, random_state=0)
kmeans_labels = kmeans.fit_predict(X)
kmeans_score = silhouette_score(X, kmeans_labels)
# Step 3: Apply EM (Gaussian Mixture Model)
gmm = GaussianMixture(n_components=2, random_state=0)
gmm.fit(X)
gmm_labels = gmm.predict(X)
gmm_score = silhouette_score(X, gmm_labels)
# Step 4: Compare results
print("K-Means Clustering Labels:", kmeans_labels)
print("GMM (EM) Clustering Labels:", gmm_labels)
print("K-Means Silhouette Score:", kmeans_score)
print("GMM Silhouette Score:", gmm_score)
# Optional: Visualize both clusters
plt.figure(figsize=(10,4))
plt.subplot(1, 2, 1)
plt.title("K-Means Clustering")
plt.scatter(X[:, 0], X[:, 1], c=kmeans_labels, cmap='viridis')
plt.subplot(1, 2, 2)
plt.title("EM - Gaussian Mixture Clustering")
plt.scatter(X[:, 0], X[:, 1], c=gmm_labels, cmap='plasma')
plt.tight_layout()
plt.show()