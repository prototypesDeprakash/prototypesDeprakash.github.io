import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
import matplotlib.pyplot as plt

data = pd.read_csv("playtennis.csv")

# 💡 Fix: Remove rows with missing values
data = data.dropna()

# Convert data
data_encoded = pd.get_dummies(data.drop('PlayTennis', axis=1))
target = data['PlayTennis'].map({'Yes': 1, 'No': 0})

# Train the model
clf = DecisionTreeClassifier(criterion='entropy')
clf = clf.fit(data_encoded, target)

# Visualize
plt.figure(figsize=(12,8))
tree.plot_tree(clf, feature_names=data_encoded.columns, class_names=['no', 'yes'], filled=True)
plt.show()
