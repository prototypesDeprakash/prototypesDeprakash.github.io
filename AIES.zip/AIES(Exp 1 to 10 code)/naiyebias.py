import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import CategoricalNB
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder

# Step 1: Load CSV file
df = pd.read_csv("playtennis.csv")

# Step 2: Encode categorical values into numbers
le = LabelEncoder()
for col in df.columns:
    df[col] = le.fit_transform(df[col])

# Step 3: Split features and labels
X = df.drop('PlayTennis', axis=1)
y = df['PlayTennis']

# Step 4: Split into training and testing sets (e.g., 70% train, 30% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)

# Step 5: Train Naive Bayes model
model = CategoricalNB()
model.fit(X_train, y_train)

# Step 6: Predict on test data
y_pred = model.predict(X_test)

# Step 7: Calculate accuracy
accuracy = accuracy_score(y_test, y_pred)
print("Predictions:", y_pred)
print("Actual:", y_test.values)
print("Accuracy:", accuracy)
