import numpy as np
import matplotlib.pyplot as plt

# Step 1: Generate simple dataset
X = np.linspace(1, 10, 100)
y = np.sin(X) + np.random.normal(0, 0.1, 100)  # Non-linear data
m = len(X)

# Add bias (column of 1s)
X_mat = np.c_[np.ones(m), X]

# Step 2: Function to compute weights (Gaussian kernel)
def weights_matrix(x_query, X, tau):
    m = len(X)
    W = np.eye(m)
    for i in range(m):
        diff = x_query - X[i]
        W[i, i] = np.exp(- (diff ** 2) / (2 * tau ** 2))
    return W

# Step 3: Locally Weighted Linear Regression prediction
def lwlr_predict(x_query, X, y, tau):
    X_mat = np.c_[np.ones(len(X)), X]
    x_query_mat = np.array([1, x_query])  # add bias term
    W = weights_matrix(x_query, X, tau)
    theta = np.linalg.pinv(X_mat.T @ W @ X_mat) @ (X_mat.T @ W @ y)
    return x_query_mat @ theta

# Step 4: Predict for all points and plot
tau = 0.5  # Bandwidth parameter
y_pred = [lwlr_predict(x, X, y, tau) for x in X]

# Step 5: Plot
plt.scatter(X, y, color='lightblue', label='Data')
plt.plot(X, y_pred, color='red', label='Locally Weighted Regression')
plt.title("Locally Weighted Linear Regression")
plt.xlabel("X")
plt.ylabel("y")
plt.legend()
plt.grid(True)
plt.show()
