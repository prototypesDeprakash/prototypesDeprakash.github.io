from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

# Step 1: Load the Iris dataset
iris = load_iris()
X = iris.data       # Features (sepal/petal length/width)
y = iris.target     # Labels (0, 1, 2 for 3 flower species)

# Step 2: Split into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)

# Step 3: Create and train the k-NN model (k=3)
knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train, y_train)

# Step 4: Make predictions
predictions = knn.predict(X_test)

# Step 5: Compare predictions with actual values
print("Correct Predictions:")
for i in range(len(y_test)):
    if predictions[i] == y_test[i]:
        print(f"Sample {i}: Predicted = {iris.target_names[predictions[i]]}, Actual = {iris.target_names[y_test[i]]}")

print("\nWrong Predictions:")
for i in range(len(y_test)):
    if predictions[i] != y_test[i]:
        print(f"Sample {i}: Predicted = {iris.target_names[predictions[i]]}, Actual = {iris.target_names[y_test[i]]}")
